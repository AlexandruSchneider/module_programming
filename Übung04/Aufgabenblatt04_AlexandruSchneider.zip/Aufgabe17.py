"""
Author: Alexandru Schneider
Datum: 13. 10. 2021
Programmiersprache: Python 3.8.8
Aufgabe 17
"""
import random

# Eingabe des Strings, wird als Liste gespeichert
givenString = list(input("Einen String eingeben: "))
print(givenString)

# Die Liste wird vermischt
random.shuffle(givenString)

# Die Liste wird zusammengehängt (also zu einem String gemacht) und ausgegeben (in der Konsole)
print("".join(givenString))
